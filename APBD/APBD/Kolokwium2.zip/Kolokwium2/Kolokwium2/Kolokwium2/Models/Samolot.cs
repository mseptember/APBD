﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace Kolokwium2.Models
{
    public class Samolot
    {
        [Key]
        public int IdSamolot { get; set; }
        [Required, MaxLength(50)]
        [Display(Name ="Model")]
        public string Model { get; set; }
        [Required]
        [Display(Name = "Data Produkcji")]
        public DateTime DataProdukcji { get; set; }
        [Required]
        [Display(Name = "Data Zakupu")]
        public DateTime DataZakupu { get; set; }
        [MaxLength(225)]
        public string Opis { get; set; }
        public int IdProducent { get; set; }
        [ForeignKey("IdProducent")]
        public Producent Producent { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Kolokwium2.Models
{
    public class Producent
    {
        [Key]
        public int IdProducnet { get; set; }

        [Required, MaxLength(50)]
        public string Nazwa { get; set; }

        public ICollection<Samolot> Samoloty { get; set; }
    }
}

﻿using System;
using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;

namespace Kolokwium2.Migrations
{
    public partial class init : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Producenci",
                columns: table => new
                {
                    IdProducnet = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    Nazwa = table.Column<string>(maxLength: 50, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Producenci", x => x.IdProducnet);
                });

            migrationBuilder.CreateTable(
                name: "Samoloty",
                columns: table => new
                {
                    IdSamolot = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    Model = table.Column<string>(maxLength: 50, nullable: false),
                    DataProdukcji = table.Column<DateTime>(nullable: false),
                    DataZakupu = table.Column<DateTime>(nullable: false),
                    Opis = table.Column<string>(maxLength: 225, nullable: true),
                    IdProducent = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Samoloty", x => x.IdSamolot);
                    table.ForeignKey(
                        name: "FK_Samoloty_Producenci_IdProducent",
                        column: x => x.IdProducent,
                        principalTable: "Producenci",
                        principalColumn: "IdProducnet",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Samoloty_IdProducent",
                table: "Samoloty",
                column: "IdProducent");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Samoloty");

            migrationBuilder.DropTable(
                name: "Producenci");
        }
    }
}

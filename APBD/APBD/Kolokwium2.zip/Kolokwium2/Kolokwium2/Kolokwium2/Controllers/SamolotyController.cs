﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Kolokwium2.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Kolokwium2.Controllers
{
    public class SamolotyController : Controller
    {
        public IActionResult Index()
        {
            var db = new SamolotDbContext();

            ViewBag.Samoloty = db.Samoloty.Include(p => p.Producent).OrderBy(p => p.Model).ToList();

            return View();
        }

        [HttpPost]
        public IActionResult Create(Samolot nowySamolot)
        {
            var db = new SamolotDbContext();

            if (!ModelState.IsValid)
            {
                ViewBag.Samoloty = db.Samoloty.Include(p => p.Producent).OrderBy(p => p.Model).ToList();

                return View("Index", nowySamolot);
            }


            
            db.Samoloty.Add(nowySamolot);
            db.SaveChanges();

            return RedirectToAction("Index");
        }
    }
}
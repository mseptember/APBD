﻿using APBD_kolokwium.Models;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace APBD_kolokwium.DAL
{
    class DbService
    {

        private EmpDbContext cont;
        public DbService()
        {
            cont = new EmpDbContext();
        }

        internal IEnumerable GetEmps()
        {
            return cont.EMP.ToList();
        }

        public IEnumerable GetSRec(string text)
        {
            return cont.EMP.ToList().Where(e => e.ENAME == text);
        }

        internal void addEmp(EMP nEmp)
        {

        }

        internal IEnumerable GetDepts()
        {
            return cont.DEPT.ToList();
        }
    }
}

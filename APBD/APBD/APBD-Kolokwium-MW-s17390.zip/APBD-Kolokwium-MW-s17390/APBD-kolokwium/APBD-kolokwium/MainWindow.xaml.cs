﻿using APBD_kolokwium.DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace APBD_kolokwium
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        private DbService dbService;
        public MainWindow()
        {
            InitializeComponent();
            dbService = new DbService();

            EmployeeDG.ItemsSource = dbService.GetEmps();
            DepartmentCB.ItemsSource = dbService.GetDepts();
        }

        private void Add_Click(object sender, RoutedEventArgs e)
        {

        }

        private void Search_Click(object sender, RoutedEventArgs e)
        {
            if(SearchTB.Text.Length < 100)
            {
                var txt = SearchTB.Text;
                EmployeeDG.ItemsSource = dbService.GetSRec(txt);
            }
            else
            {
                MessageBox.Show("Za dużo znaków", "Deans Office", MessageBoxButton.OK, MessageBoxImage.Asterisk);
            }
        }

        private void Show_Click(object sender, RoutedEventArgs e)
        {
            EmployeeDG.ItemsSource = dbService.GetEmps();
        }
    }
}
